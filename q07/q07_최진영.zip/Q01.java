package com.test.question.q07;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Q01 {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		String str = "";
//		
//		
//		System.out.println("�ִ� ���� : ");
//		int max = Integer.parseInt(br.readLine());
//		for(int i =0; i <= max; i++) {
//			
//			if(i/10 == 3 | i/10 == 6  | i/10 == 9 ) {
//				if(i%10 == 3 | i%10 == 6  | i%10 == 9 ) {
//					str += "¦¦";
//					
//					continue;
//				}
//				
//				srt += "¦";
//				
//			}else if (i%10 == 3 | i%10 == 6  | i%10 == 9  )
//				
//		
//		}
//		
		
	}

}
