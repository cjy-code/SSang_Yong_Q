package com.test.question.q04;

import java.util.Calendar;

public class Q01 {

	public static void main(String[] args) {
		
		nowTime();
		nowTime_AMPM();
		
	}//main

	private static void nowTime_AMPM() {
        Calendar now = Calendar.getInstance();
		
		int hour = now.get(Calendar.HOUR_OF_DAY);
		int min =now.get(Calendar.MINUTE); 
		int sec = now.get(Calendar.SECOND);
		int ampm = now.get(Calendar.AM_PM);
		String strAmpm = (ampm == Calendar.AM) ? "����" : "����";
		
		System.out.printf("%s %d�� %d�� %d��",strAmpm, hour%12, min, sec);
		
		
		
	}

	private static void nowTime() {
		Calendar now = Calendar.getInstance();
		
		int hour = now.get(Calendar.HOUR_OF_DAY);
		int min =now.get(Calendar.MINUTE); 
		int sec = now.get(Calendar.SECOND);
		
		System.out.printf("���� �ð� : %d�� %d�� %d��\n", hour, min ,sec);
			
	}
	

}
