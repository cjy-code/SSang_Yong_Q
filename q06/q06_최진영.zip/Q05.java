package com.test.question.q06;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Q05 {
	
public static void main(String[] args) throws IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("�Ʒ��� �Է��ϼ���.");
		
		
		for(;;) {
			String chat = br.readLine();
			if(chat.equals("")) {
				break;
			}
			
		}
		
		
		
   }
}
