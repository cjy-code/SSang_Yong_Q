package com.test.question.q17;

public class Student {
	
	private String name;
	private int age;
	private int grade;
	private int classNumber;
	private int number;
	
	
	public Student() {
		this.name = "����";
	}
	
	public Student(String name, int age, int grade, int classNumber, int number) {
		this.name = name;
		this.age = age; 
		this.grade = grade;
		this.classNumber = classNumber;
	}
	
	public Student(String name, int age) {
		this.name = name;
		this.age = age; 
		
	}
	
	public Student(int grade, int classNuber, int number) {
		this.name = "����";
		this.number =number;
		this.grade = grade;
		this.classNumber = classNumber;
	}
	
	public String info() {
		
	 return String.format("%s(���� : %s, �г� : %s, �� : %s, ��ȣ : %s)"
				, this.name
				, this.age != 0 ? this.age + "��" : "����"
				, this.grade != 0 ? this.grade : "����"
				, this.classNumber != 0 ? this.grade : "����"
				, this.number != 0 ? this.grade : "����");
	
	
	}
	
}
