package com.test.question.q16;

public class Macaron {
	
	private int size;
	private int thickness;
	private String color;
	
	
	public int getSize() {
		size = (int) (Math.random() * 15 + 1); // 1~15���� ������ ��

		if (size >= 5 && size <= 15) { // 5~ 15cm ��ȯ
			this.size = size;
		}

		return size;
	}
	public void setSize(int size) {
		
		
		this.size = size;
	}

	
	public String getColor() {
		
		String[] M_color = {"red", "blue", "yellow", "white", "pink","purple","green","black"};
		int a = (int) (Math.random() * 8);
		color = M_color[a];
		
		return color;
	}
	public void setColor(String color) {
		
			this.color = color;
	}
	
	
	public int getThickness() {// ���� �α�
		
		thickness = (int) (Math.random() * 20 + 1); //���� ���� �α� 1~20

		if (size >= 3 && size <= 18) { // 5~ 15cm
			this.thickness = thickness;
		}
		return thickness;
	}

	public void setThickness(int thickness) {

		
		this.thickness = thickness;
	}

}
