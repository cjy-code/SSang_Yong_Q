package com.test.question.q16;

public class Box {
	
	private Macaron[] list = new Macaron[10];// ��ī�� 10��
	private int pass_Count =0;
	private int fail_Count =0;
	
	public void cook() {
		
		for(int i=0; i<list.length; i++) {
			Macaron m = new Macaron();
			
			m.getColor();
			m.getSize();
			m.getThickness();
			
			this.list[i] = m;
			
		}
		
		
		System.out.printf("��ī�� %d���� ��������ϴ�.\n\n",list.length);
		
	}
	
	public void check() {
		

		
		for (int i = 0; i < 10; i++) {
			int color = (int) (Math.random() * 8 + 1)-1;

			Macaron m =this.list[i];
			
			if (check(m)) {
					this.pass_Count++;
			} else {
					this.fail_Count++;
			}
		}
		
		System.out.println("[�ڽ� üũ ���]");
		System.out.printf("QC �հ� ���� : %d\n", this.pass_Count );
		System.out.printf("QC ���հ� ���� : %d\n", this.fail_Count);
		
		
		System.out.println();
		
	}//check
	public void list() {
		
		
        
        
        System.out.println("[��ī�� ���]");
		
        for (int i = 0; i < 10; i++) {
        	
        	Macaron m = this.list[i];
		

			if (m.getColor().equals("blcak") || // ����, ũ�� 8�̻� 14���ϰ� �ƴϰų�,  
			   (m.getSize()<8 && m.getSize()<14) ||// �β� 3mm~18mm�� �ƴϸ� ����
			   (m.getThickness() <3 && m.getThickness() >18)){
				System.out.printf("%dcm(%s, %d,mm): ���հ�\n",m.getSize(),m.getColor(),m.getThickness());
				this.pass_Count++;
			} else {
				System.out.printf("%dcm(%s, %d,mm): �հ�\n",m.getSize(),m.getColor(),m.getThickness());
				this.pass_Count++;
			}	
		}
		
	    
		
		
	}//list

private boolean check(Macaron m) {
		
		//QC(ũ��)
		if (!(m.getSize() >= 8 && m.getSize() <= 14)) {
			return false;
		}
		
		//QC(����)
		if (m.getColor().equals("black")) {
			return false;
		}
		
		//QC(�β�)
		if (!(m.getSize() >= 3 && m.getSize() <= 18)) {
			return false;
		}
		
		return true;
	}
}
