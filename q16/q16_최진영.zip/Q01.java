package com.test.question.q16;

public class Q01 {
	
	public static void main(String[] args) {
		
		//��ī�� 
		Box box1 = new Box();
		box1.cook();
		box1.check();
		box1.list();
		
	}

}

