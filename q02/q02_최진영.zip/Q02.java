package com.test.question.q02;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Q02 {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("���� �Է� : ");
		int input = Integer.parseInt(br.readLine());
	
        digit(input);
		
		
		
		
		
	}//main
	
	public static void digit(int num) {
		
		System.out.printf("%04d",num);
	}
	

}
