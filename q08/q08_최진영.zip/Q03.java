package com.test.question.q08;

public class Q03 {
	
	public static void main(String[] args) {
		
		for(int i=0; i <5; i++) {
						
			for(int j=0; j<= 4; j++) {
				if(i <= j) {
					System.out.print("*");
				}else
					System.out.print(" ");
			}					
			System.out.println();
		}
	}

}
