package com.test.question.q10;

public class Q01 {
	public static void main(String[] args) {
		
		String txt = "�ȳ��ϼ���. ȫ�浿�Դϴ�.";
		String result = "";
		for(int i=txt.length()-1; i>=0; i--) {
			
			result += txt.charAt(i);
		}
		System.out.print(result);
	}

}
