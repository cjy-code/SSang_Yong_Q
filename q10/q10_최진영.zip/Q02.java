package com.test.question.q10;

public class Q02 {
	public static void main(String[] args) {
		
		String email = "hong@gmail.com";
		
		int index = email.indexOf('@');
		System.out.printf("���̵� : %s\n", email.substring(0, index));
		System.out.printf("������ : %s\n", email.substring(index+1, email.length()));
		
		
	}

}
