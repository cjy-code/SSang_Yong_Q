package com.test.question.q10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Q03 {
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String txt = br.readLine();
		
		String c = "";
		int sum =0;
		
		
		for(int i=0; i< txt.length(); i++) {
			c += txt.charAt(i);
			sum += txt.charAt(i)-47;
			if(i==txt.length()-1) {
				break;
			}
			c+= " + ";
		}
		System.out.printf("%s = %d",c,sum);
		
		
	}

}
